#pragma once

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <time.h>

#include "SFML/System.hpp"
#include "SFML/Graphics.hpp"
#include "SFML/Window.hpp"
#include "SFML/Audio.hpp"

#include "XephEngine/Debug.h";
#include "XephEngine/InputSystem.h"

#include "../src/Structs.h"
